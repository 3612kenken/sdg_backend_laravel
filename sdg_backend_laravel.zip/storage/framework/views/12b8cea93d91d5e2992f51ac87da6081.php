 <footer>
                <div class="footer clearfix mb-0 text-muted">
                    <div class="float-left">
                        <p>2024 &copy; Marinduque State University</p>
                    </div>
                    <div class="float-right">
                        <p>Crafted with <span class='text-danger'><i data-feather="heart"></i></span> by <a href="#">CICS Developer Team</a></p>
                    </div>
                </div>
            </footer><?php /**PATH D:\Laravel\sdg_backend_laravel\resources\views/api-ui/footer.blade.php ENDPATH**/ ?>