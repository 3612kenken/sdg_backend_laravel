<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<body>

</body>
</html><?php /**PATH D:\Laravel\sdg_backend_laravel\resources\views\api-ui\records.blade.php ENDPATH**/ ?>